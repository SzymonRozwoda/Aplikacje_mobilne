package com.example.lista_inf04;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> notes;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editTextNewNote = findViewById(R.id.editTextNewNote);
        Button buttonAddNote = findViewById(R.id.buttonAddNote);
        ListView listViewNotes = findViewById(R.id.listViewNotes);

        notes = loadNotesFromFile();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notes);
        listViewNotes.setAdapter(adapter);

        buttonAddNote.setOnClickListener(v -> {
            String newNote = editTextNewNote.getText().toString().trim();
            if (!newNote.isEmpty()) {
                notes.add(newNote);
                adapter.notifyDataSetChanged();
                editTextNewNote.setText("");
            }
        });
    }

    private ArrayList<String> loadNotesFromFile() {
        ArrayList<String> loadedNotes = new ArrayList<>();
        try {
            InputStream inputStream = getResources().openRawResource(R.raw.dane);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                loadedNotes.add(line);
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return loadedNotes;
    }
}
