package com.example.super_komponenty;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomCircleView extends View {
    private Paint paint;
    private float circleX;
    private float circleY;
    private float radius = 100f;

    public CustomCircleView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(Color.GREEN);
        paint.setAntiAlias(true);


        circleX = 500f;
        circleY = 500f;
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(circleX, circleY, radius, paint);
    }

    public void setCircleRadius(float newRadius) {
        radius = newRadius;
        invalidate();
    }

    public void setCircleColor(int color) {
        paint.setColor(color);
        invalidate();
    }

    public void setCirclePosition(float x, float y) {
        circleX = x;
        circleY = y;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_MOVE) {
            circleX = event.getX();
            circleY = event.getY();
            invalidate();
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            setCircleColor(Color.RED);
            return true;
        }
        return super.onTouchEvent(event);
    }

    public void animateCircleSize() {
        ObjectAnimator animator = ObjectAnimator.ofFloat(this, "circleRadius", radius, 300f);
        animator.setDuration(1000);
        animator.start();
    }
}
