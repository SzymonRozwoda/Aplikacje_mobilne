package com.example.super_komponenty;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        CustomCircleView circleView = findViewById(R.id.customCircleView);


        circleView.setCircleRadius(150f);


        circleView.animateCircleSize();
    }
}