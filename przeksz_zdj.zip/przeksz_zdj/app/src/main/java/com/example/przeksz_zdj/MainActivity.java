package com.example.przeksz_zdj;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import java.util.Random;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button button;
    private Button button2;
    private Bitmap oldBitmap;
    private Bitmap newBitmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            return insets;
        });
        imageView = findViewById(R.id.imageView);
        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                oldBitmap = BitmapFactory.decodeResource(getResources(),R.drawable.samplebmpfilessample_640x426);
                imageView.setImageBitmap(oldBitmap);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (oldBitmap !=null){
                    newBitmap = oldBitmap.copy(oldBitmap.getConfig(),true);
                    modyfikuj(newBitmap);
                    imageView.setImageBitmap(newBitmap);
                }
            }
        });





    }
    private void modyfikuj(Bitmap bitmap){

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        int[] tempPixels = new int[width * height];

        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

        Random random = new Random();

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {

                int offsetX = random.nextInt(7) - 3;
                int offsetY = random.nextInt(7) - 3;


                int newX = Math.min(Math.max(x + offsetX, 0), width - 1);
                int newY = Math.min(Math.max(y + offsetY, 0), height - 1);


                tempPixels[newY * width + newX] = pixels[y * width + x];
            }
        }


        bitmap.setPixels(tempPixels, 0, width, 0, 0, width, height);
    }
}