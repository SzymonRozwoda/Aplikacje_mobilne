package com.example.bitmapa_i_ksztalty;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Button buttonCreate, buttonClear, buttonLine, buttonEllipse, buttonSquare;
    private FiguryView figuryView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        buttonCreate = findViewById(R.id.button);
        buttonClear = findViewById(R.id.button2);
        buttonLine = findViewById(R.id.button3);
        buttonEllipse = findViewById(R.id.button4);
        buttonSquare = findViewById(R.id.button5);
        figuryView = findViewById(R.id.figuryView);

        figuryView.setCurrentShapeType("line");

        buttonCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Adds shapes each time "kreuj" is pressed
                addRandomShapes();
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                figuryView.clearShapes();
            }
        });

        buttonLine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                figuryView.setCurrentShapeType("line");
            }
        });

        buttonEllipse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                figuryView.setCurrentShapeType("ellipse");
            }
        });

        buttonSquare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                figuryView.setCurrentShapeType("square");
            }
        });
    }

    private void addRandomShapes() {
        Random random = new Random();
        int numberOfShapes = random.nextInt(4) + 2;

        figuryView.post(new Runnable() {
            @Override
            public void run() {
                int viewWidth = figuryView.getWidth();
                int viewHeight = figuryView.getHeight();

                String currentType = figuryView.getCurrentShapeType();

                for (int i = 0; i < numberOfShapes; i++) {
                    float startX = random.nextFloat() * viewWidth;
                    float startY = random.nextFloat() * viewHeight;
                    float endX = startX + random.nextFloat() * (viewWidth / 4);
                    float endY = startY + random.nextFloat() * (viewHeight / 4);

                    endX = Math.min(endX, viewWidth);
                    endY = Math.min(endY, viewHeight);

                    int color = Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));

                    figuryView.addShape(startX, startY, endX, endY, color);
                }
            }
        });
    }
}
