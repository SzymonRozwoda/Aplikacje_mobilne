package com.example.bitmapa_i_ksztalty;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class FiguryView extends View {

    private static class Shape {
        String type;
        float startX, startY, endX, endY;
        int color;

        Shape(String type, float startX, float startY, float endX, float endY, int color) {
            this.type = type;
            this.startX = startX;
            this.startY = startY;
            this.endX = endX;
            this.endY = endY;
            this.color = color;
        }
    }

    private List<Shape> shapes;
    private String currentShapeType = "line";
    private Paint paint;


    private Bitmap bitmap;
    private Canvas bitmapCanvas;

    public FiguryView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        shapes = new ArrayList<>();
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setStrokeWidth(5);
        paint.setStyle(Paint.Style.STROKE);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {

        super.onSizeChanged(w, h, oldw, oldh);
        if (bitmap != null) {
            bitmap.recycle();
        }
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bitmapCanvas = new Canvas(bitmap);
        bitmapCanvas.drawColor(Color.WHITE);
        redrawBitmap();
    }

    private void redrawBitmap() {
        if (bitmapCanvas != null) {

            bitmapCanvas.drawColor(Color.WHITE);

            for (Shape shape : shapes) {
                paint.setColor(shape.color);
                switch (shape.type) {
                    case "line":
                        bitmapCanvas.drawLine(shape.startX, shape.startY, shape.endX, shape.endY, paint);
                        break;
                    case "ellipse":
                        RectF oval = new RectF(shape.startX, shape.startY, shape.endX, shape.endY);
                        bitmapCanvas.drawOval(oval, paint);
                        break;
                    case "square":
                        RectF rect = new RectF(shape.startX, shape.startY, shape.endX, shape.endY);
                        bitmapCanvas.drawRect(rect, paint);
                        break;
                    default:
                        break;
                }
            }
            invalidate();
        }
    }

    public void setCurrentShapeType(String shapeType) {
        // Clear shapes if the new shape type differs from the current type
        if (!this.currentShapeType.equals(shapeType)) {
            clearShapes();  // Clear all shapes when switching types
        }
        this.currentShapeType = shapeType;
    }


    public String getCurrentShapeType() {
        return currentShapeType;
    }

    public void addShape(float startX, float startY, float endX, float endY, int color) {
        shapes.add(new Shape(currentShapeType, startX, startY, endX, endY, color));

        if (bitmapCanvas != null) {
            paint.setColor(color);
            switch (currentShapeType) {
                case "line":
                    bitmapCanvas.drawLine(startX, startY, endX, endY, paint);
                    break;
                case "ellipse":
                    RectF oval = new RectF(startX, startY, endX, endY);
                    bitmapCanvas.drawOval(oval, paint);
                    break;
                case "square":
                    RectF rect = new RectF(startX, startY, endX, endY);
                    bitmapCanvas.drawRect(rect, paint);
                    break;
                default:
                    break;
            }
            invalidate();
        }
    }

    public void clearShapes() {
        shapes.clear();
        if (bitmapCanvas != null) {
            bitmapCanvas.drawColor(Color.WHITE);
            invalidate();
        }
    }
    public int getShapeCount() {
        return shapes.size();
    }



    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (bitmap != null) {
            canvas.drawBitmap(bitmap, 0, 0, null);
        }
    }

}
