package com.example.lista2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class AddTaskActivity extends AppCompatActivity {
    private EditText editTextName;
    private EditText editTextDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        editTextName = findViewById(R.id.editTextName);
        editTextDescription = findViewById(R.id.editTextDescription);

        Button buttonSave = findViewById(R.id.buttonSave);
        buttonSave.setOnClickListener(this::saveTask);
    }

    private void saveTask(View view) {
        String name = editTextName.getText().toString();
        String description = editTextDescription.getText().toString();

        Intent resultIntent = new Intent();
        resultIntent.putExtra("name", name);
        resultIntent.putExtra("description", description);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}

