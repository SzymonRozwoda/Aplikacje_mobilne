package com.example.lista2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class TaskDetailActivity extends AppCompatActivity {
    private EditText editTextName;
    private EditText editTextDescription;
    private Button buttonSave;
    private ArrayList<Task> taskList;
    private int taskIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_detail);

        editTextName = findViewById(R.id.editTextName);
        editTextDescription = findViewById(R.id.editTextDescription);
        buttonSave = findViewById(R.id.buttonSave);


        taskList = (ArrayList<Task>) getIntent().getSerializableExtra("taskList");
        taskIndex = getIntent().getIntExtra("taskIndex", -1);


        if (taskIndex >= 0 && taskIndex < taskList.size()) {
            Task task = taskList.get(taskIndex);
            editTextName.setText(task.getName());
            editTextDescription.setText(task.getDescription());
        } else {
            Log.e("TaskDetailActivity", "Invalid task index: " + taskIndex);
            finish();
        }

        buttonSave.setOnClickListener(v -> {
            String updatedName = editTextName.getText().toString();
            String updatedDescription = editTextDescription.getText().toString();

            Intent resultIntent = new Intent();
            resultIntent.putExtra("name", updatedName);
            resultIntent.putExtra("description", updatedDescription);
            resultIntent.putExtra("taskIndex", taskIndex);
            setResult(RESULT_OK, resultIntent);
            finish();
        });



    }
}