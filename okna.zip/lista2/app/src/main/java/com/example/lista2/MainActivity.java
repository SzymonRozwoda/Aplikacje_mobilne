package com.example.lista2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_ADD_TASK = 1;
    private static final int REQUEST_EDIT_TASK = 2;
    private RecyclerView recyclerView;
    private TaskAdapter taskAdapter;
    private ArrayList<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskList = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskAdapter = new TaskAdapter(taskList, (task, position) -> onTaskSelected(task, position));

        recyclerView.setAdapter(taskAdapter);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
            startActivityForResult(intent, REQUEST_ADD_TASK);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == REQUEST_ADD_TASK) {
                // Dodawanie nowego zadania
                String name = data.getStringExtra("name");
                String description = data.getStringExtra("description");

                if (name != null && description != null) {
                    taskList.add(new Task(name, description));
                    taskAdapter.notifyDataSetChanged();
                }

            } else if (requestCode == REQUEST_EDIT_TASK) {
                // Edytowanie istniejącego zadania
                int taskIndex = data.getIntExtra("taskIndex", -1);
                String updatedName = data.getStringExtra("name");
                String updatedDescription = data.getStringExtra("description");

                if (taskIndex >= 0 && taskIndex < taskList.size()) {
                    Task task = taskList.get(taskIndex);
                    task.update(updatedName, updatedDescription);
                    taskAdapter.notifyItemChanged(taskIndex);
                }
            }
        }
    }



    private void onTaskSelected(Task task, int position) {
        Intent intent = new Intent(MainActivity.this, TaskDetailActivity.class);
        intent.putExtra("taskList", taskList); // taskList musi być serializowalny
        intent.putExtra("taskIndex", position);
        startActivityForResult(intent, REQUEST_EDIT_TASK);  // Używamy REQUEST_EDIT_TASK tutaj
    }



    private void openTaskDetail(int position) {
        Intent intent = new Intent(MainActivity.this, TaskDetailActivity.class);
        intent.putExtra("taskList", taskList);
        intent.putExtra("taskIndex", position);
        startActivityForResult(intent, 1);
    }






}
